package com.example.urclean.model;

public enum estadoNotificacion
{
    ENPROCESO,CONCEDIDO,RECHAZADO;
}
