package com.example.urclean.model;

public enum estadoQueja
{
    NOTIFICADA, RECIBIDA, SOLUCIONADA;
}
