package com.example.urclean.model;

public enum estadoRespuesta
{
    VISTO, NOVISTO;
}
